#pragma once
int getSize(const char* pInfo);
void showMenu();
void add();
void query();
void exitApp();
void logon();
void settle();
void recharge();
int refund();
int logoff();
int statistics();
#pragma once
void showMenu();
void add();
int getSize(char* pInfo);
void copy(char* input, char* output, int size);
void query();
void copy(const char aInput[], char aOutput[], int nSize);
#pragma once
int SaveCard(const Card* pCard, const char* pPath);
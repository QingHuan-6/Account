#define _CRT_SECURE_NO_WARNINGS
#include<time.h>
void TimeToString(time_t t, char* pbuf)
{
	struct tm* pTimeInfo;
	pTimeInfo = localtime(&t);
	strftime(pbuf, 20, "%Y-%m-%d %H:%M",pTimeInfo);
}
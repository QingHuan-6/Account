#pragma once
#include"model.h"
int addCard(Card card);
Card* queryCard(const char*pName);
void releaseCardList();
Card* queryCards(const char* pName, int* pIndex);
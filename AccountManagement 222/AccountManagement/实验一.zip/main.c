#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include<Windows.h>
#include "menu.h"
#
int main()
{
	char ch;
	int nSelection = -1;
	while (1)
	{
		showMenu();
		scanf("%d", &nSelection);
		while ((ch = getchar()) != '\n')//����������
		{

		}
		switch (nSelection)
		{
		case 1: add(); break;
		case 2:	query(); break;
		case 3: printf("�ϻ�\n"); break;
		case 4: printf("�»�\n"); break;
		case 5: printf("��ֵ\n"); break;
		case 6: printf("�˷�\n"); break;
		case 7: printf("��ѯͳ��\n"); break;
		case 8: printf("ע����\n"); break;
		case 0: printf("�˳�\n"); break;
		default: printf("wrong!\n"); break;
		}
		if (nSelection == 0)
		{
			printf("��лʹ��\n");
			system("pause");
			return 0;
		}
		else
		{
			continue;
		}
	}
	system("pause");
	return 0;
}